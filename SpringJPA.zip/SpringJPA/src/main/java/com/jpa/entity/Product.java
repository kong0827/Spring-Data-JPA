package com.jpa.entity;

import javax.persistence.*;

@Entity(name = "cst_product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pro_id")
    private int proId;

    @Column(name = "pro_price")
    private double proPrice;

    @Column(name = "pro_size")
    private String proSize;

    public int getProId() {
        return proId;
    }

    public void setProId(int proId) {
        this.proId = proId;
    }

    public double getProPrice() {
        return proPrice;
    }

    public void setProPrice(double proPrice) {
        this.proPrice = proPrice;
    }

    public String getProSize() {
        return proSize;
    }

    public void setProSize(String proSize) {
        this.proSize = proSize;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    private int orderId;

    public Product(int proId, double proPrice, String proSize, int orderId) {
        this.proId = proId;
        this.proPrice = proPrice;
        this.proSize = proSize;
        this.orderId = orderId;
    }

    public Product() {
    }

    @Override
    public String toString() {
        return "Product{" +
                "proId=" + proId +
                ", proPrice=" + proPrice +
                ", proSize=" + proSize +
                ", orderId=" + orderId +
                '}';
    }
}
